package com.test.email.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.minimalFrame.email.service.EmailService;

import lombok.Data;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/resources/mailConfig.xml")
@Data
@Log4j
public class EmailServiceTest {

	private EmailService emailService;

	@Test
	public void emailTest() {
		ApplicationContext context = new ClassPathXmlApplicationContext("mailConfig.xml");
		EmailService emailService = (EmailService) context.getBean("emailService");
		emailService.sendEmail("rcl8912@gmail.com", "Test Mail", "<h1>Hello</h1>");
		log.info("메일 보내기 성공!");
	}
}
