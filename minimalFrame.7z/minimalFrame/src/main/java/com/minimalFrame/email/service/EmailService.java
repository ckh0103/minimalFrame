package com.minimalFrame.email.service;

import java.util.Random;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.minimalFrame.member.service.MemberService;

import lombok.Data;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@Data
public class EmailService {
    
	@Autowired
    private MemberService service;
    
	@Autowired
	private JavaMailSender mailSender; // 메일 전송해주는 클래스

    // 인증 코드 생성
    public String authCode(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(random.nextInt(10)); // 0~9 사이의 랜덤 숫자 추가
        }
        return sb.toString();
    }
	
	public void sendEmail(String to, String subject, String text) { // to : 수신인

		// 필수 정보 검증
		if (to == null || subject == null || text == null) {
			log.error("필수 정보가 누락되었습니다. 다시 확인해주세요.");
			return;
		}

		MimeMessage message = mailSender.createMimeMessage(); // 메일 속성(수신인, 제목, 내용) 설정 가능하게 하는 클래스

		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8"); // 이메일 본문 내용을 HTML로 설정할 수 있음
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(text, true);

			mailSender.send(message);

			log.info("============================");
			log.info("=======인증코드 발송 완료========");
			log.info("============================");

		} catch (Exception e) {
			e.printStackTrace(); // 개발 이후 주석 처리
			log.error("============================");
			log.error("=====!!!인증코드 발송 실패!!!=====");
			log.error("============================");
		}

	}
	
	// 이메일 발송 및 인증 코드 DB에 저장
    public void authCodeSendEmail(String email) {
        String authCode = authCode(6); // 인증 코드 생성
        String subject = "회원가입 이메일 인증 코드입니다.";
        String text = "인증 코드: " + authCode; // 이메일 내용

        System.out.println("인증 코드 확인용: " + authCode);
        
        sendEmail(email, subject, text); // 이메일 발송

        service.insertAuthCode(email, authCode); // DB에 인증 코드 저장
    }

    // 인증 코드 검증
    public boolean checkAuthCode(String email, String authCode) {
        String storedAuthCode = service.getAuthCode(email); // DB에서 인증 코드 조회
        return storedAuthCode != null && storedAuthCode.equals(authCode);
    }

    // 비밀번호 찾기용 이메일 발송
    public void sendPasswordResetEmail(String email, String memberId, String contextPath) {
        // 비밀번호 변경 링크 생성 - 매개변수 이름 통일 및 URL 오류 수정
        String link = contextPath + "/member/user/editPasswordForm.do?memberId=" + memberId;
        
        String subject = "비밀번호 재설정 안내";
        String text = "회원님이 요청하신 비밀번호 재설정 링크: " + link;
        
        sendEmail(email, subject, text);
    }
    
}
