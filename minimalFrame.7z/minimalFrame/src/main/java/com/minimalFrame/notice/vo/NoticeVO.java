package com.minimalFrame.notice.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class NoticeVO {

	private Long noticeNo;		// 번호
	private String title;		// 제목
	private String content;		// 내용
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date startDate;		// 공지 시작일
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;		// 공지 종료일
	
	private Date writeDate;		// 최초 작성일
	private Date updateDate;	// 최근 수정일
	
	private String importNotice;	// 중요공지
	private String imageFile;		// 이미지
	
	private String memberId;

	// private String gnrFile;		// 일반 파일
	
	
	
	
}
