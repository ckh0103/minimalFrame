package com.minimalFrame.notice.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.minimalFrame.notice.vo.NoticeVO;
import com.minimalFrame.util.page.PageObject;

@Repository
public interface NoticeMapper {

	// 공지사항 리스트
	public List<NoticeVO> list(PageObject pageObject);
	
	
	// getTotalRow : 전체 데이터 가져요기.
	public Long getTotalRow(PageObject pageObject);
	
	
	// view
	public NoticeVO view(Long noticeNo);
	
	// write
	public int write(NoticeVO vo);
	
	// delete
	public int delete(NoticeVO vo);
	
	// update
	public int update(NoticeVO vo);
	
	// importNoticeMapper
	/*
	 * public int importNoticeMapper(NoticeVO vo);
	 * 
	 */
}
