package com.minimalFrame.notice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minimalFrame.notice.mapper.NoticeMapper;
import com.minimalFrame.notice.vo.NoticeVO;
import com.minimalFrame.util.page.PageObject;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class NoticeService {
	
	 //mapper 자동 DI
	@Setter(onMethod_ = @Autowired)
	private NoticeMapper mapper;
	
	// 1. 공지 list
	public List<NoticeVO> list(PageObject pageObject){
		
		// 전체 데이터 개수를 받아서 pageObject에 넣는다. - getTotalRow
		pageObject.setTotalRow(mapper.getTotalRow(pageObject));	
		
		return mapper.list(pageObject);

	}
	
	// view
	public NoticeVO view(Long noticeNo) {
		
		return mapper.view(noticeNo);
	}
	
	// write 
	public int write(NoticeVO vo) {
		return mapper.write(vo);
	}
	
	// update 
	public int update(NoticeVO vo) {
		return mapper.update(vo);
	}
	
	// delete
	public int delete(NoticeVO vo) {
		return mapper.delete(vo);
	}
	
	// 중요 / 비중요
	/*
	 * public int importNoticeMapper(NoticeVO vo) { return
	 * mapper.importNoticeMapper(vo); }
	 */
	
	
	
	
}
