package com.minimalFrame.notice.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.minimalFrame.notice.service.NoticeService;
import com.minimalFrame.notice.vo.NoticeVO;
import com.minimalFrame.util.file.FileUtil;
import com.minimalFrame.util.page.PageObject;

import lombok.Data;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/notice")
@Log4j
@Data
public class NoticeController {	

	
	//NoticeService service
	@Setter(onMethod_ = @Autowired)
	private NoticeService service;
	
	private final String PATH = "/upload/notice";
	private final int SLEEP_TIME = 700;

	
	// 1. list

	@GetMapping("/list.do")
	public String list(HttpServletRequest request, Model model, PageObject pageObject, NoticeVO noticeVO) throws Exception {
		
		log.info(pageObject);

		model.addAttribute("list", service.list(pageObject));
		
		log.info(pageObject);
		model.addAttribute("pageObject", pageObject);

		System.out.println("TEAM1 미니멀프레임- MINIMALFRAME controller/ list.do ==============================SYSOUT ");
	

		return "notice/list_1";
	}
	
	
	// 2. view
	@GetMapping("/view.do")
	public String view(Long noticeNo, Model model, int perPageNum) {
		
		model.addAttribute("vo", service.view(noticeNo));
		
		//return "notice/view_1?noticeNo="+noticeNo;
		return "notice/view_1";
	}
	
	
	// 3-1 . writeForm 
	@GetMapping("/writeForm.do")
	public String writeForm() {
		return "notice/writeForm_1";
	}
	
	
	// 3-2. write

	
	@PostMapping("/write.do")
	public String write(NoticeVO noticeVO, @RequestParam("uploadFile") MultipartFile imageFile, int perPageNum, HttpServletRequest request, RedirectAttributes rttr) throws Exception {		

		
		noticeVO.setImageFile(FileUtil.upload(PATH, imageFile, request));
		
		log.info(" noticeVO ============== : " + noticeVO);
		
		int result = service.write(noticeVO);
		Thread.sleep(SLEEP_TIME);
		
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "공지 등록 완료했습니다.");
			return "redirect:list.do?perPageNum="+perPageNum;

		}else {
			rttr.addAttribute("resultMessage", "공지 등록 실패했습니다.");
			return "redirect:list.do?perPageNum="+perPageNum;
		}
		
		
	}
	
	
	// 4-1 . updateForm
	@GetMapping("/updateForm.do")
	public String updateForm(Long noticeNo, Model model) {
		
		model.addAttribute("vo", service.view(noticeNo));
		
		return "notice/updateForm_1";
	}
	
	
	
	// 4-2. update

	@PostMapping("/update.do")
	public String update(NoticeVO noticeVO, HttpSession session, RedirectAttributes rttr, int perPageNum) throws Exception {

		int result = service.update(noticeVO);



		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "공지 수정 완료했습니다.");
			return "redirect:list.do?noticeNo=" + perPageNum;

		}else {
			rttr.addAttribute("resultMessage", "공지 수정 실패했습니다.");
			return "redirect:list.do?perPageNum=" + perPageNum;
		}
		
		
	}
	
	
	
	// 5. delete 
	
	@GetMapping("/delete.do")
	public String delete(Long noticeNo, NoticeVO noticeVO, String deleteFile, RedirectAttributes rttr) throws Exception{
		
		noticeVO.setMemberId("second");
		
		int result = service.delete(noticeVO);
/*		
		if(result == 1) {
			try {			
				FileUtil.remove(deleteFile);
			}catch(Exception ex) {
				log.warn("파일 삭제를 하지못했습니다.");
				ex.printStackTrace();
				
			}
		}
*/		
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "공지 삭제 완료했습니다.");
			return "redirect:list.do?noticeVO=" + noticeVO;
		}else {
			rttr.addAttribute("resultMessage", "공지 삭제 실패했습니다.");
			return "redirect:list.do?noticeVO=" + noticeVO;		}
			
			
	}	
	
	
	
	
}
