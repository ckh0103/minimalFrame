package com.minimalFrame.item.vo;

import lombok.Data;

@Data
public class ItemVO{

	private Long itemNo; //상품 번호 (기본 키)
	private String itemName; //상품명
	private String itemContent; //상품 설명
	private String itemImage; //상품 이미지 URL 또는 파일명
	private Integer price; //가격
	private Long purchase; //구매 횟수;
	private Integer categoryId; //카테고리 ID (외래 키)
	private String categoryName; //카테고리 이름

	private String memberId;
}
