package com.minimalFrame.item.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;

import com.minimalFrame.item.service.ItemService;
import com.minimalFrame.item.vo.CategoryVO;
import com.minimalFrame.item.vo.ItemVO;
import com.minimalFrame.member.vo.MemberVO;
import com.minimalFrame.util.file.FileUtil;
import com.minimalFrame.util.page.PageObject;

import lombok.Data;
import lombok.extern.log4j.Log4j;

//자동 생성 - @Controller, @Service, @Repository, @Component, @RestController, @~Advice
//저장할 때에 이름 타입의 맨 앞자리를 소문자로 해서 저장해 놓는다. 타입이 매칭이 되면 꺼내서 넣어준다.
//설정 - root-context.xml, servlet-context.xml :<context:component-scan base-package="org.zerock" />
@Controller
// 자동으로 setter() getter() toString()
// 로그 출력 객체 log 선언
@Log4j
// url 모듈
@RequestMapping("/item")
public class ItemController {

	// 자동 DI를 이용해서 service 등록시키기 - @Setter - lombok, @Autowired - Spring, @Inject -
	// java
	@Autowired
	private ItemService service;

	// 파일의 저장 위치(웹에서 사용되는 상대 적인 위치) -> 파일 저장하면 절대 위치가 필요하다.(프로그램)
	private final String PATH = "/upload/item";
	// 이미지 올라가는 시간 딜레이
	private final int SLEEP_TIME = 700;

	// /board/list.do
//	@RequestMapping("/list.do") // get과 post 둘다 받는다.
	@GetMapping("/list.do") // get과 post 둘다 받는다.
	// 전달되는 name과 변수이름이 같으면 데이터가 전달된다.
	// 전달되는 name이 없으면 기본값 세팅 가능 - @RequestParam(defaultValue = "1")
	// public String list(@RequestParam(defaultValue = "1") Long page, Model model)
	// {
	public String list(HttpServletRequest request, Model model) throws Exception {
		log.info("상품 리스트 Controller");
//		System.out.println(service);

		// 페이지 처리를 위한 객체
		PageObject pageObject = PageObject.getInstance(request);
		// perPageNum이 10이 8로 바꾸자.
		if (pageObject.getPerPageNum() == 10)
			pageObject.setPerPageNum(8);

		// 넘어 오는 데이터 확인
//		log.info("page=" + page);
//		log.info(pageObject);

		// model에 데이터를 담으면 request에 자동으로 담긴다. -> JSP에서 사용 가능.
		model.addAttribute("list", service.list(pageObject));

		log.info(pageObject);

		// pageObject는 JSP에서 사용자가 클릭할 수 있는 페이지 버튼을 제공한다. JSP까지 보내야 한다.
		model.addAttribute("pageObject", pageObject);

		// /WEB-INF/views/ + image/list + .jsp
		return "item/list";
	}

	// item/writeForm.do
	@GetMapping("/writeForm.do")
	public String writeForm(Model model) {
		// 폼에 데이터를 추가하고 싶으면 여기서 추가할 수 있습니다.
		// 예: 카테고리 목록, 기타 필요한 데이터 등
		model.addAttribute("categoryList", service.categoryList());

		// /WEB-INF/views/ + board/writeForm + .jsp
		return "item/writeForm";
	}

	// /item/write.do
	@PostMapping("/write.do")
	// title, content 는 vo로 자동으로 받는다. 파일 데이터 imageFile을 따로 받는다.
	public String write(ItemVO vo, MultipartFile imageFile, int perPageNum, HttpServletRequest request)
			throws Exception {

		// 폴더가 없는 경우 - 1. 프로그램 작성 폴더 만들기. 2. 수동으로 만들어 놓으면 된다.

		// 파일 업로드 처리하기 추가한다.
		vo.setItemImage(FileUtil.upload(PATH, imageFile, request));

		log.info(vo);

		// [ImageController] - ImageService - ImageMapper
		service.write(vo);

		// 이미지 로딩 시간을 벌어 주자. 처리 시스템 재운다. 0.7초 - 700
		Thread.sleep(SLEEP_TIME);

		// list로 바로 이동.
		return "redirect:list.do?perPageNum=" + perPageNum;
	}

	// /itemImage/view.do
	// 전달받는 데이터 - 글번호
	@GetMapping("/view.do")
	public String view(@RequestParam(required = true) Long itemNo, Model model) {
	
		//소문자로 써야한다.service 
//		model.addAttribute("itemNo", service.view(itemNo));

		// log로 처리된 결과 출력
		log.info(model);
		
		// /WEB-INF/views/ + image/view + .jsp
		return "item/view";
	}

	// 1. 상품 수정 폼
	@GetMapping("/updateForm.do")
	public String updateForm(Long itemNo, Model model) {

		// 소문자로 써야한다.service 
		// 글번호에 맞는 데이터 가져오기. - 글보기 서버스 호출 no - 받은 데이터, inc - 0으로 세팅해서 넘긴다.
		model.addAttribute("vo", service.view(itemNo));

		// /WEB-INF/views/ + image/updateForm + .jsp
		return "item/updateForm";
	}

	// 2. 상품 수정 처리 - 번호, 제목, 내용이 넘어온다.
	@PostMapping("/update.do")
	public String update(ItemVO vo, PageObject pageObject, HttpSession session) throws Exception {

		int result = service.update(vo);

		return "redirect:view.do?no=" + vo.getItemNo() + "&" + pageObject.getPageQuery();

	}

	// 3. 이미지 바꾸기 처리
	@PostMapping("/changeImage.do")
	public String changeImage(ItemVO vo, PageObject pageObject, MultipartFile imageFile, String deleteFile,
			HttpServletRequest request) throws Exception {

		// 글번호:전달된다., 아이디, 파일이름
		// vo.setId("test");
		// 파일 처리
		vo.setItemImage(FileUtil.upload(PATH, imageFile, request));

		// 데이터 처리
		int result = service.changeImage(vo);

		// 이미지는 올라가고 있고 프로그램을 계속 진행되서 글보기로 가버린다. - 이미지 안보임.
		Thread.sleep(SLEEP_TIME);

		try {
			// 이미지 지우기 - result에 따라. 1 - deleteFile 지우기, 0 - vo.fileName
			if (result == 1)
				FileUtil.remove(deleteFile);
			else
				FileUtil.remove(vo.getItemImage());
		} catch (Exception e) {
			log.warn("파일이 존재하지 않기 때문에 삭제하지 못했습니다.");
		}

		return "redirect:view.do?no=" + vo.getItemNo() + "&" + pageObject.getPageQuery();
	}

	// 5. 상품 삭제 - 작성된 이미지가 로그인한 회원의 아이디로 작성된 글만 삭제 가능 - 1.화면. 2. 권한처리
	@GetMapping("/delete.do")
	public String delete(ItemVO vo, int perPageNum, String deleteFile, HttpSession session) throws Exception {

		// 6. 상품 가격 바꾸기
		// 관리자가 입력 팝업 창에서 입력 데이터를 입력

		// 7. 상품 삭제
		// 관리자가 상품보기화면에서 삭제버튼을 클릭한후에
		// 관리자는 등록된 상품의 상품번호, 상품 이미지 명의 데이터를 자동으로 세팅하게 한다.
		// DB 삭제 처리
		int result = service.delete(vo);

		// result 가 0이면 전달데이터가 정확하지 않기 때문에 처리를 진행한다.
		// 파일삭제
		if (result == 1)
			try {
				FileUtil.remove(deleteFile);
			} catch (Exception e) {
				log.warn("파일이 존재하지 않아서 삭제를 하지 못했습니다.");
			}

		// 처리가 다 끝나면 리스트로 바로 이동시킨다.
		return "redirect:list.do?perPageNum=" + perPageNum;

	}
}
