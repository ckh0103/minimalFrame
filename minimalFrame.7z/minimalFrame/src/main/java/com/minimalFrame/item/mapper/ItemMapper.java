package com.minimalFrame.item.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.minimalFrame.item.vo.CategoryVO;
import com.minimalFrame.item.vo.ItemVO;
import com.minimalFrame.util.page.PageObject;


@Mapper
public interface ItemMapper { // ImageDAO에 해당
	// 1. list
		// 구현되는 처리문은 mybatis가 작성해서 실행한다. - 정보만 전달 - 1.전달 데이터, 2. SQL, 3. 결과
		public List<ItemVO> list(PageObject pageObject); 
		
		// 1-1. 전체 데이터 개수를 가져오는 메서드
		public Long getTotalRow(PageObject pageObject);
		// 2.1  카테고리VO list
		public List<CategoryVO> list();
	
		
		// 2. 상품보기 데이터
		public ItemVO view(Long itemNo);
		
		// 3. 상품등록 
		public Integer write(ItemVO vo) ;

		// 4-1. 정보 수정 - 제목, 내용만
		public int update(ItemVO Vo);
		
		// 4-2. 이미지 (fileName) 수정
		public int changeImage(ItemVO Vo);
		
		// 5. 글삭제
		public int delete(ItemVO vo);

		public int insertItem(ItemVO vo);

		public ItemVO itemController(Long no);

		public List<CategoryVO> categoryList();
		
	}


