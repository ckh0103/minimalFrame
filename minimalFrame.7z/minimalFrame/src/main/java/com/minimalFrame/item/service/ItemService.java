package com.minimalFrame.item.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minimalFrame.item.mapper.ItemMapper;
import com.minimalFrame.item.vo.CategoryVO;
import com.minimalFrame.item.vo.ItemVO;
import com.minimalFrame.util.page.PageObject;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

//자동 생성 - @Controller, @Service, @Repository, @Component, @RestController, @~Advice
//저장할 때에 이름 타입의 맨 앞자리를 소문자로 해서 저장해 놓는다. 타입이 매칭이 되면 꺼내서 넣어준다.
//설정 - root-context.xml, servlet-context.xml :<context:component-scan base-package="org.zerock" />
@Service
@Log4j
//ImageController - [ImageService] - ImageMapper
public class ItemService {

		// 자동 DI - @Setter. @Autowired, @Inject
			@Setter(onMethod_ = @Autowired)
			private ItemMapper mapper;
	
		// 리스트
		public List<ItemVO> list(PageObject pageObject) {
			log.info("상품 리스트 서비스");
			
			// page, perPageNum, startPage, endPage, totalPage 계산이 되고 데이터가 세팅된다.
			pageObject.setTotalRow(mapper.getTotalRow(pageObject));
			
			return mapper.list(pageObject);
		}
		


		/*
		 * // public static Object view(Long no) { // TODO Auto-generated method stub
		 * return null; }
		 * 
		 * public int update(ItemVO vo) { // TODO Auto-generated method stub return 0; }
		 */
	
		public int changeImage(ItemVO vo) {
		// TODO Auto-generated method stub
		return 0;
		}
	
		public int delete(ItemVO vo) {
			// TODO Auto-generated method stub
			return 0;
		}
	
		// 카테고리 리스트 조회 
		public List<CategoryVO> categoryList() {
			return mapper.categoryList();
		}
	
		// 아이템 등록
		public Integer write(ItemVO vo) {
			
			return mapper.write(vo);
		}
		
	    // 글보기
		public ItemVO view(Long itemNo) {
			
			return mapper.view(itemNo);
		}
		
		public int update(ItemVO vo) {
			// TODO Auto-generated method stub
			return 0;
		}
	
	
	}
