
package com.minimalFrame.item.vo;

import lombok.Data;

@Data
public class CategoryVO {

	   private Integer categoryId;
	    private String categoryName;
}
