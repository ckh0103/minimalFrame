package com.minimalFrame.qna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.minimalFrame.qna.mapper.QnaMapper;
import com.minimalFrame.qna.vo.AnswerVO;
import com.minimalFrame.qna.vo.QuestionVO;
import com.minimalFrame.util.page.PageObject;

@Service
public class QnaService {

	@Autowired
	private QnaMapper mapper;
	
	// list 
	public List<QuestionVO> getQuestions(PageObject pageObject) {
		
		pageObject.setTotalRow(mapper.getTotalRow(pageObject));
		
		return mapper.getQuestions(pageObject); 
	}	


	// 질문 추가
	public int addQuestion(QuestionVO questionVO) {
		//QnaMapper
        return mapper.addQuestion(questionVO);
	}
	
    // 답변 추가
    public int addAnswer(AnswerVO answerVO) {
    	return mapper.addAnswer(answerVO);
    }

    
    public QuestionVO AnswerWrite(Long questionNo) {
        return mapper.AnswerWrite(); 
    }	
    
    // 답변 조회 (세부사항 보기)
	
	  public AnswerVO getAnswer(Long questionNo) {
		  return mapper.getAnswer(questionNo); 
	 }
	 

    // 특정 질문에 대한 답변 조회
    public List<AnswerVO> getAnswers(Long questionNo) {
        return mapper.getAnswers(questionNo);  
    }    
   
    // 특정 질문 조회 (세부사항 보기)
    public QuestionVO getQuestion(Long questionNo) {
        return mapper.getQuestion(questionNo);  
    }
    
    
    // 답변 삭제
    public int deleteAnswers(AnswerVO answerVO) {
    	return mapper.deleteAnswers(answerVO);
    }
    
    // 질문 삭제
    public int deleteQuestion(QuestionVO questionVO) {
    	return mapper.deleteQuestion(questionVO);
    }


    // 질문 수정
	public int updateQuestion(QuestionVO questionVO) {
		// TODO Auto-generated method stub
		return mapper.updateQuestion(questionVO);
	}

	// 답변 수정
	public int updateAnswer(AnswerVO answerVO) {
		// TODO Auto-generated method stub
		return mapper.updateAnswer(answerVO);
	}





}





