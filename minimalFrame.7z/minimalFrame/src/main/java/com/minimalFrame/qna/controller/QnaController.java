package com.minimalFrame.qna.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.minimalFrame.member.vo.MemberVO;
import com.minimalFrame.qna.service.QnaService;
import com.minimalFrame.qna.vo.AnswerVO;
import com.minimalFrame.qna.vo.QuestionVO;
import com.minimalFrame.util.page.PageObject;

import lombok.Data;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/qna")
@Log4j
@Data
public class QnaController {

	@Autowired
	private QnaService qnaService;
	
	
	// 질문 목록 조회
	@GetMapping("/list.do")
	public String list(Model model, PageObject pageObject) {

		log.info(pageObject);

		model.addAttribute("questions", qnaService.getQuestions(pageObject));

		model.addAttribute("pageObject", pageObject);
		log.info(pageObject);

		return "qna/list";
	}
	
	// 질문 추가 form
	@GetMapping("/writeForm.do")
	public String writeForm() {
		return "qna/writeForm";
	}
	
	// 질문 추가
	@PostMapping("/addQuestion.do")
	public String addQuestion(QuestionVO questionVO, MultipartFile imageFile, HttpServletRequest request, RedirectAttributes rttr, HttpSession session) throws Exception {
		

		
		
		log.info(MemberVO.getMemberId(session) + " : ============== MemberVO.getMemberId(session) ====================================================================");
		
		questionVO.setMemberId(MemberVO.getMemberId(session));
		int result = qnaService.addQuestion(questionVO);		
		
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "질문 등록 완료했습니다.");
			return "redirect:list.do?questionVO="+ questionVO.getQuestionNo();

		}else {
			rttr.addAttribute("resultMessage", "질문 등록 실패했습니다.");
			return "redirect:list.do?questionVO="+ questionVO.getQuestionNo();
		}
		
		
		
	}
	
    //VIEW
    // 특정 질문 조회 (세부사항 보기)
    @RequestMapping("/question.do")
    public String getQuestion(@RequestParam("questionNo") Long questionNo, Model model, HttpServletRequest request) {
  
       model.addAttribute("question", qnaService.getQuestion(questionNo));  // 서비스 호출
       model.addAttribute("answers", qnaService.getAnswers(questionNo));  // 서비스 호출
      // model.addAttribute("answerView", qnaService.getAnswer(questionNo));  // 서비스 호출
       
       return "qna/view";  // JSP 페이지 이름 반환
    }
	
    // 답변 추가 form
	@GetMapping("/AnswerWrite.do")
	public String writeFormAnswer(Model model, Long questionNo, QuestionVO questionVO) {
	 
		model.addAttribute("question", qnaService.getQuestion(questionNo)); 

	    log.info( "  model.addAttribute(\"question\", qnaService.getQuestion(questionNo)); ===========================" + model.addAttribute("question", qnaService.getQuestion(questionNo)));
	    
		return "qna/AnswerWrite";
	}
	
	
	
    
    // writeAnswer
    @RequestMapping("/addAnswer.do")
    public String addAnswer(AnswerVO answerVO, QuestionVO questionVO, PageObject pageObject, HttpServletRequest request, Model model, RedirectAttributes rttr, HttpSession session) throws Exception{
    	
      //  qnaService.addAnswer(answerVO);  // 서비스 호출
        
       // return "redirect:question.do";  // 특정 질문 페이지로 리다이렉트
		//qnaService.addQuestion(questionVO);
    	
    	
		log.info(answerVO +"  ================================== answerVO ==================================");
		log.info(questionVO +" ================================== questionVO ===================================");
		questionVO.setMemberId(MemberVO.getMemberId(session));
    	int result = qnaService.addAnswer(answerVO);
    	
    	
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "답변 등록 완료했습니다.");
	    	return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();

		}else {
			rttr.addAttribute("resultMessage", "답변 등록 실패했습니다.");
	    	return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();
		}

    	
    }	
    
	
    
    // 답변 삭제 ( 회원, 비외원은 본인 작성 글만 / 관리자는 모두 )
    @RequestMapping("/deleteAnswers.do")
    public String deleteAnswers( AnswerVO answerVO, QuestionVO questionVO, HttpServletRequest request, RedirectAttributes rttr) throws Exception{
    //public String deleteAnswers(Long answers, AnswerVO answerVO, QuestionVO questionVO) throws Exception{
    	
    	int result = qnaService.deleteAnswers(answerVO);
    	    	
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "답변 삭제 완료했습니다.");
			return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();

		}else {
			rttr.addAttribute("resultMessage", "답변 삭제 실패했습니다.");
			return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();
		}
    	
    	
    }
    
    // 질문 삭제 ( 회원, 비외원은 본인 작성 글만 / 관리자는 모두 )
    @RequestMapping("/deleteQuestion.do")
    public String deleteQuestion(QuestionVO questionVO, HttpServletRequest request, RedirectAttributes rttr) throws Exception{
    	
    	int result = qnaService.deleteQuestion(questionVO);
    			
		
		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "질문 삭제 완료했습니다.");
			return "redirect:list.do";

		}else {
			rttr.addAttribute("resultMessage", "질문 삭제 실패했습니다.");
			return "redirect:list.do";
		}
    	
    }
    
    
    
    // 질문 수정
	@PostMapping("/updateQuestion.do")
	public String updateQuestion(QuestionVO questionVO, HttpSession session, RedirectAttributes rttr) throws Exception {

		int result = qnaService.updateQuestion(questionVO);

		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "질문 수정 완료했습니다.");
	    	return "redirect:list.do?questionNo="+ questionVO.getQuestionNo();

		}else {
			rttr.addAttribute("resultMessage", "질문 수정 실패했습니다.");
	    	return "redirect:list.do?questionNo="+ questionVO.getQuestionNo();
		}
		
		
	}
	
    // 답변 수정
	@PostMapping("/updateAnswer.do")
	public String updateAnswer(AnswerVO answerVO, HttpSession session, RedirectAttributes rttr,QuestionVO questionVO) throws Exception {

		int result = qnaService.updateAnswer(answerVO);



		if(result > 0) {
			rttr.addFlashAttribute("resultMessage", "답변 수정 완료했습니다.");
	    	return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();

		}else {
			rttr.addAttribute("resultMessage", "답변 수정 실패했습니다.");
	    	return "redirect:question.do?questionNo="+ questionVO.getQuestionNo();
		}
		
		
	}
    
    
	
}
