package com.minimalFrame.qna.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.minimalFrame.qna.vo.AnswerVO;
import com.minimalFrame.qna.vo.QuestionVO;
import com.minimalFrame.util.page.PageObject;

@Repository
public interface QnaMapper {

	// list
	public List<QuestionVO> getQuestions(PageObject pageObject);
	
	// 1-2. getTotalRow : 전체 데이터 가져요기.
	public Long getTotalRow(PageObject pageObject);

	// writeQ
    public int addQuestion(QuestionVO questionVO);
    
    // 답변 추가
    public int addAnswer(AnswerVO answerVO);

    // 특정 질문에 대한 답변 조회
    public List<AnswerVO> getAnswers(Long questionNo);
    
    // 특정 질문에 대한 답변 조회
	/* public AnswerVO getAnswer(Long questionNo); */

    // 특정 질문 조회 (세부사항 보기)
    public QuestionVO getQuestion(Long questionNo);
    
    // 답변 삭제
    public int deleteAnswers(AnswerVO answerVO);
    
    // 질문 삭제
    public int deleteQuestion(QuestionVO questionVO);
    
    // 답변 작성 폼
	public QuestionVO AnswerWrite();


	public AnswerVO getAnswer(Long answersVO);

	// 질문 수정
	public int updateQuestion(QuestionVO questionVO);

	// 답변 수정
	public int updateAnswer(AnswerVO answerVO);
    


	
    
    
    
}
