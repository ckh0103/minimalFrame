package com.minimalFrame.qna.vo;

import java.sql.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class AnswerVO {

    private Long answersNo;
    private Long questionNo;
    private String content;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date writeDate;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date updateDate;
    private String status;

    private String title;
    private Long answerNumber;

	
}
