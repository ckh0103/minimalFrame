package com.minimalFrame.main.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    
    @GetMapping({"/", "main.do"})
    public String main(Model model) {
    	
        double latitude = 37.739499;  // 위도
        double longitude = 127.044802; // 경도
        
        
        // JSP로 위치 정보 전달
        model.addAttribute("latitude", latitude); // 방법 1: 위도, 경도를 각각 전달
        model.addAttribute("longitude", longitude);
        
        return "main";
    }
}