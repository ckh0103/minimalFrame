package com.minimalFrame.util.exception;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;

import lombok.extern.log4j.Log4j;

// 자동 생성 - @Controller, @Service, @Repository, @Component, @RestController, @~Advice
@ControllerAdvice
@Log4j
public class CommonExceptionAdvice {

	// Exception을 잡아서 처리(500번 오류)
	@ExceptionHandler(Exception.class) // catch(Exception e)
	public String except(Exception ex, Model model) {
	
		log.error("Exception ......" + ex.getMessage());
		model.addAttribute("exception", ex);
		log.error(model);
		
		return "error/500";
	}
	
	// 요청하신 페이지 없음 처리(404) - URI가 없는 경우 - 처리가 끝나고 JSP 없는 경우엔 web.xml에서
	@ExceptionHandler(NoHandlerFoundException.class)
	// 브라우저에게 요청에 대한 처리 상태를 알려준다. - 404
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public String handle404(NoHandlerFoundException ex) {
		
		return "error/404";
	}
}
