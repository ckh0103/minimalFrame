package com.minimalFrame.util.filter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.minimalFrame.member.vo.MemberVO;

import lombok.extern.log4j.Log4j;

/**
 * Servlet Filter implementation class AuthorityFilter
 */
@Log4j
public class AuthorityFilter implements Filter {

	// key:String:uri, value:Integer:gradeNo
	private Map<String, Integer> authMap = new HashMap<>();
	
    /**
     * Default constructor. 
     */
    public AuthorityFilter() {
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// place your code here - 요청한 처리 전에 처리되는 부분 : 권한, 보안 처리
		// 사용자의 요청 = URI와 같다. - request(HttpServletRequest)
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response; // sendRedirect() 필요
		
		String uri = req.getRequestURI();
		
		log.info(uri);
		
		// 페이지를 보기 위한 권한 - 숫자로 가져온다. authMap에서 꺼내온다. : 미리 저장해둬야 한다. - init()
		Integer pageGradeNo = authMap.get(uri);
		
		// 페이지에 접근 할 때 로그인을 필수로 만드는 처리.
		if(pageGradeNo != null) {
			// 로그인이 되어있는지 확인 - LoginVO에서 getGradeNo(session) 사용해서 정보를 수집한다.
			Integer gradeNo = MemberVO.getGradeNo(req);
			// 로그인이 안되어 있으면 - gradeNo == null -> 로그인 페이지로 이동시킨다.
			if(gradeNo == null) {
				res.sendRedirect("/member/loginForm.do");
				return; // 밑에 작성된 처리문이 실행되지 않도록 처리
			}
			// 관리자 권한에 대한 처리 - 사용자의 권한(gradeNo)이 페이지 권한(pageGradeNo)보다 작은 경우(권한 없음)
			if(gradeNo < pageGradeNo) {
				req.getRequestDispatcher("/WEB-INF/views/error/authority.jsp").forward(req, res);
				return;
			}
		}
		
		// pass the request along the filter chain - 요청한 처리 부분으로 이동
		chain.doFilter(request, response);
		
		
		// 요청한 처리가 끝나고 처리되는 부분 : sitemesh
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// authMap에 데이터 저장하기 - 요구사항 정의서의 권한 / 모든 사용자(일반 사용자) 권한은 제외시킨다.

		// 공지사항 - 등록, 수정, 삭제 - 관리자(9)
		authMap.put("/notice/writeForm.do", 9);
		authMap.put("/notice/write.do", 9);
		authMap.put("/notice/updateForm.do", 9);
		authMap.put("/notice/update.do", 9);
		authMap.put("/notice/changeImage.do", 9);
		authMap.put("/notice/delete.do", 9);
		
		// 이미지 게시판 - 등록, 수정, 이미지 바꾸기, 삭제 - 일반 사용자(1)
		authMap.put("/image/writeForm.do", 1);
		authMap.put("/image/write.do", 1);
		authMap.put("/image/updateForm.do", 1);
		authMap.put("/image/update.do", 1);
		authMap.put("/image/changeImage.do", 1);
		authMap.put("/image/delete.do", 1);
		
	}

}
