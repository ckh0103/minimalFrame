package com.minimalFrame.util.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;

// AOP 객체라고 지정.
@Aspect
@Log4j
// 자동 생성 - @controller / @service / @repository / @component / @restcontroller, @~advice
@Component
// Service 실행에 대한 로그를 출력하는 AOP 처리(advice)
public class LogAdvice {

	@Around("execution(* com.minimalFrame.*.service.*Service.*(..))")
	public Object logTime(ProceedingJoinPoint pjp) throws Throwable {
		
		Object result = null;

		log.info("***** AOP ******************");
		
		// 서비스 처리 이전의 처리문
		Long start = System.nanoTime();
		
		// 목적하는 서비스 프로그램 실행이 진행되는 처리
		result = pjp.proceed();
		
		// 서비스 처리 이후의 처리문
		Long end = System.nanoTime();
		
		// 로그 출력 - 넘어가는 데이터, 실행되는 객체, 결과 데이터, 실행 시간
		log.info("*========================================*");
		log.info("* 실행 객체 : " + pjp.getTarget().getClass().getName());
		log.info("* 실행 메서드 : " + pjp.getSignature().getName() + "()");
		log.info("*========================================*");
		log.info("* 전달 데이터 : " + Arrays.toString(pjp.getArgs()));
		log.info("* 처리 결과 : " + result);
		log.info("* 실행 시간 : " + (end - start));
		log.info("*========================================*");
		return result;
	}
	
}
