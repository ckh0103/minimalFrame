package com.minimalFrame.basketOpt.vo;

// 필요한 라이브러리 임포트
import java.util.Date;

public class BasketOptVO {
    // 옵션 장바구니 아이디 (PK)
    private int basketOptId;
    
    // 장바구니 아이디 (basket과 연동)
    private int basketId;
    
    // 옵션 번호
    private int optionNo;
    
    // 수량
    private int quantity;
    
    // 추가된 날짜
    private Date addedDate;

    // 기본 생성자
    public BasketOptVO() {}

    // 모든 필드를 포함하는 생성자
    public BasketOptVO(int basketOptId, int basketId, int optionNo, int quantity, Date addedDate) {
        this.basketOptId = basketOptId;
        this.basketId = basketId;
        this.optionNo = optionNo;
        this.quantity = quantity;
        this.addedDate = addedDate;
    }

    // Getter & Setter 메서드들
    public int getBasketOptId() {
        return basketOptId;
    }

    public void setBasketOptId(int basketOptId) {
        this.basketOptId = basketOptId;
    }

    public int getBasketId() {
        return basketId;
    }

    public void setBasketId(int basketId) {
        this.basketId = basketId;
    }

    public int getOptionNo() {
        return optionNo;
    }

    public void setOptionNo(int optionNo) {
        this.optionNo = optionNo;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getAddedDate() {
        return addedDate;
    }

    public void setAddedDate(Date addedDate) {
        this.addedDate = addedDate;
    }
}
