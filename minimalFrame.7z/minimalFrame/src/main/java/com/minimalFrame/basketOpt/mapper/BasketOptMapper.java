package com.minimalFrame.basketOpt.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.minimalFrame.basketOpt.vo.BasketOptVO;

// MyBatis 매퍼 인터페이스 선언
@Mapper
public interface BasketOptMapper {
    
    // 특정 장바구니 아이디에 대한 옵션 목록 조회
    List<BasketOptVO> getBasketOptList(@Param("basketId") int basketId);
    
    // 옵션 장바구니에 옵션 추가
    void addBasketOptItem(BasketOptVO basketOpt);
    
    // 옵션 장바구니에서 특정 옵션 삭제
    void removeBasketOptItem(@Param("basketOptId") int basketOptId);
    
    // 특정 장바구니 아이디에 해당하는 옵션 전체 삭제
    void clearBasketOpt(@Param("basketId") int basketId);
}
