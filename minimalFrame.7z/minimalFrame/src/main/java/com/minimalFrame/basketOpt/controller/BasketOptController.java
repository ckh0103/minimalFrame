package com.minimalFrame.basketOpt.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.minimalFrame.basketOpt.service.BasketOptService;
import com.minimalFrame.basketOpt.vo.BasketOptVO;

@Controller
@RequestMapping("/basketOpt")
public class BasketOptController {
    
    // BasketOptService 자동 주입
    @Autowired
    private BasketOptService basketOptService;

    // 옵션 목록 조회
    @GetMapping("/list")
    public String getBasketOptList(@RequestParam("basketId") int basketId, Model model) {
        List<BasketOptVO> basketOptList = basketOptService.getBasketOptList(basketId);
        model.addAttribute("basketOptList", basketOptList);
        return "basketOpt/basketOptList"; // JSP 파일 경로
    }

    // 옵션 장바구니에 옵션 추가
    @PostMapping("/add")
    public String addBasketOptItem(@ModelAttribute BasketOptVO basketOpt) {
        basketOptService.addBasketOptItem(basketOpt);
        return "redirect:/basketOpt/list?basketId=" + basketOpt.getBasketId();
    }

    // 옵션 장바구니에서 특정 옵션 삭제
    @PostMapping("/remove")
    public String removeBasketOptItem(@RequestParam("basketOptId") int basketOptId, @RequestParam("basketId") int basketId) {
        basketOptService.removeBasketOptItem(basketOptId);
        return "redirect:/basketOpt/list?basketId=" + basketId;
    }

    // 특정 장바구니 아이디의 옵션 전체 삭제
    @PostMapping("/clear")
    public String clearBasketOpt(@RequestParam("basketId") int basketId) {
        basketOptService.clearBasketOpt(basketId);
        return "redirect:/basketOpt/list?basketId=" + basketId;
    }
}
