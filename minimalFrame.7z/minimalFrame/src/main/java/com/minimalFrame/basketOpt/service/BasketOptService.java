package com.minimalFrame.basketOpt.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.minimalFrame.basketOpt.mapper.BasketOptMapper;
import com.minimalFrame.basketOpt.vo.BasketOptVO;

@Service
public class BasketOptService {
    
    // BasketOptMapper 자동 주입
    @Autowired
    private BasketOptMapper basketOptMapper;

    // 옵션 목록 조회
    public List<BasketOptVO> getBasketOptList(int basketId) {
        return basketOptMapper.getBasketOptList(basketId);
    }

    // 옵션 장바구니에 옵션 추가
    public void addBasketOptItem(BasketOptVO basketOpt) {
        basketOptMapper.addBasketOptItem(basketOpt);
    }

    // 옵션 장바구니에서 특정 옵션 삭제
    public void removeBasketOptItem(int basketOptId) {
        basketOptMapper.removeBasketOptItem(basketOptId);
    }

    // 특정 장바구니 아이디의 옵션 전체 삭제
    public void clearBasketOpt(int basketId) {
        basketOptMapper.clearBasketOpt(basketId);
    }
}
