package com.minimalFrame.basket.mapper;

import com.minimalFrame.basket.vo.BasketVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BasketMapper {

    // 로그인된 사용자 장바구니 목록 조회
    List<BasketVO> getBasketListByMemberId(@Param("memberId") String memberId);

    // 장바구니 아이템 추가
    void addBasketItem(BasketVO basket);

    // 장바구니 아이템 삭제
    void removeBasketItem(@Param("basketId") int basketId);

    // 장바구니 비우기
    void clearBasket(@Param("memberId") String memberId);
}
