package com.minimalFrame.basket.controller;

import com.minimalFrame.basket.service.BasketService;
import com.minimalFrame.basket.vo.BasketVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
public class BasketController {

    @Autowired
    private BasketService basketService;

    // 장바구니 목록 조회
    @GetMapping("/basket/list.do")
    public String getBasketList(HttpSession session, Model model) {
        String memberId = (String) session.getAttribute("memberId");  // "memberId"를 세션에서 가져옴

        List<BasketVO> basketList;
        if (memberId == null) {
            // 비로그인 사용자는 세션 기반 장바구니 사용
            basketList = (List<BasketVO>) session.getAttribute("basketList");
            if (basketList == null) {
                basketList = new ArrayList<>(); // 장바구니가 없으면 빈 리스트
            }
        } else {
            // 로그인 사용자는 DB에서 장바구니 조회
            basketList = basketService.getBasketListByMemberId(memberId);  // memberId로 장바구니 조회
        }

        model.addAttribute("basketList", basketList);
        return "basket/basketList";
    }

    // 장바구니에 상품 추가
    @PostMapping("/basket/add")
    public String addBasketItem(@ModelAttribute BasketVO basket, HttpSession session) {
        String memberId = (String) session.getAttribute("memberId");  // 세션에서 memberId 가져오기

        if (memberId != null) {
            basket.setMemberId(memberId);  // memberId를 BasketVO에 설정
            basketService.addBasketItem(basket);  // DB에 장바구니 추가
        } else {
            // 비회원은 세션 기반 장바구니 사용
            List<BasketVO> basketList = (List<BasketVO>) session.getAttribute("basketList");
            if (basketList == null) {
                basketList = new ArrayList<>();
            }
            basketList.add(basket);  // 장바구니에 추가
            session.setAttribute("basketList", basketList);  // 세션에 장바구니 저장
        }

        return "redirect:/basket/list.do";
    }

    // 장바구니에서 특정 상품 삭제
    @PostMapping("/basket/remove")
    public String removeBasketItem(@RequestParam("basketId") int basketId, HttpSession session) {
        String memberId = (String) session.getAttribute("memberId");  // 세션에서 memberId 가져오기

        if (memberId != null) {
            basketService.removeBasketItem(basketId);  // 로그인한 사용자는 DB에서 삭제
        } else {
            // 비회원은 세션에서 장바구니 삭제
            List<BasketVO> basketList = (List<BasketVO>) session.getAttribute("basketList");
            if (basketList != null) {
                basketList.removeIf(basket -> basket.getBasketId() == basketId);  // 해당 상품 삭제
                session.setAttribute("basketList", basketList);  // 세션에 장바구니 저장
            }
        }

        return "redirect:/basket/list.do";
    }

    // 장바구니 결제하기 버튼 클릭 시 로그인 확인
    @GetMapping("/basket/checkout")
    public String checkout(HttpSession session) {
        String memberId = (String) session.getAttribute("memberId");  // 세션에서 memberId 가져오기

        if (memberId == null) {
            // 비로그인 사용자는 로그인 페이지로 이동
            return "redirect:/member/loginForm.do";
        }

        return "redirect:/orders/checkout.do";  // 로그인된 사용자는 결제 페이지로 이동
    } 
}
