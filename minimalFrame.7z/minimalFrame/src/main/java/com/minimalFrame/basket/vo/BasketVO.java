package com.minimalFrame.basket.vo;

public class BasketVO {
    private String memberId; // "userId" 대신 "memberId"
    private int itemId;
    private String itemName;
    private int quantity;
    private int price;

    // Getter and Setter for memberId (userId를 memberId로 변경)
    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    // Getter and Setter for itemId
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    // Getter and Setter for itemName
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    // Getter and Setter for quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter and Setter for price
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

	public int getBasketId() {
		// TODO Auto-generated method stub
		return 0;
	}
}
