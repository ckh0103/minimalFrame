package com.minimalFrame.basket.service;

import com.minimalFrame.basket.vo.BasketVO;
import com.minimalFrame.basket.mapper.BasketMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BasketService {

    @Autowired
    private BasketMapper basketMapper;

    // 로그인한 사용자의 장바구니 조회
    public List<BasketVO> getBasketListByMemberId(String memberId) {
        return basketMapper.getBasketListByMemberId(memberId);  // memberId로 장바구니 조회
    }

    // 장바구니에 상품 추가
    public void addBasketItem(BasketVO basket) {
        basketMapper.addBasketItem(basket);  // 장바구니에 상품 추가
    }

    // 장바구니에서 상품 삭제
    public void removeBasketItem(int basketId) {
        basketMapper.removeBasketItem(basketId);  // 장바구니에서 상품 삭제
    }

    // 비회원 장바구니 관리 (세션에서 관리됨)
    // 필요한 경우 비회원 장바구니 처리 로직 추가
}
