package com.minimalFrame.config;

import javax.sql.DataSource;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;
import org.apache.ibatis.io.Resources;
import java.io.Reader;

@Configuration
@MapperScan(basePackages = {
       "com.minimalFrame.basket.mapper",
       "com.minimalFrame.basketOpt.mapper",
       "com.minimalFrame.orders.mapper",
       "com.minimalFrame.delivery.mapper",
       "com.minimalFrame.member.mapper",
       "com.minimalFrame.notice.mapper",
       "com.minimalFrame.item.mapper", 
       "com.minimalFrame.qna.mapper"
       })
public class MyBatisConfig {

    private static SqlSessionFactory sqlSessionFactory;

    static {
        try {
            // HikariCP 설정
            HikariConfig hikariConfig = new HikariConfig();
            hikariConfig.setDriverClassName("net.sf.log4jdbc.sql.jdbcapi.DriverSpy");
            hikariConfig.setJdbcUrl("jdbc:log4jdbc:oracle:thin:@192.168.0.231:1521/minimalpdb");
            hikariConfig.setUsername("minimalframe");
            hikariConfig.setPassword("minimalframe");
            
            DataSource dataSource = new HikariDataSource(hikariConfig);

            // MyBatis 설정
            String resource = "mybatis-config.xml";
            Reader reader = Resources.getResourceAsReader(resource);
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
            sqlSessionFactory.getConfiguration().setEnvironment(
                new org.apache.ibatis.mapping.Environment(
                    "development",
                    new org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory(),
                    dataSource
                )
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static SqlSessionFactory getSqlSessionFactory() {
        return sqlSessionFactory;
    }
}