package com.minimalFrame.orders.vo;

// 필요한 라이브러리 임포트
public class OrdersVO {
    // 주문 번호 (PK) - orderNo로 수정
    private int orderNo;

    // 사용자 ID (FK)
    private String memberId;

    // 총 주문 금액
    private int totalAmount;

    // 주문 상태 (예: '결제 완료', '배송 중' 등)
    private String orderState;

    // 주문 날짜
    private String orderDate;

    // 배송지 정보
    private String dlvyName;
    private String recipient;
    private String tel;
    private String addr;
    private String addrDetail;
    private int postNo;
    private String dlvyMemo;

    // 상품 정보
    private int itemNo;
    private int orderPrice;
    private Integer pointShopGoodsNo;
    private int dlvyCharge;
    private String payWay;
    private String payDetail;
    private String paymentKey;

    // 주문 상태 및 기타
    private String confirmDate;
    private int reviewExist;
    private String cancelReason;
    private int amount;

    // 기본 생성자
    public OrdersVO() {}

    // 모든 필드를 포함하는 생성자
    public OrdersVO(int orderNo, String memberId, int totalAmount, String orderState, String orderDate) {
        this.orderNo = orderNo;
        this.memberId = memberId;
        this.totalAmount = totalAmount;
        this.orderState = orderState;
        this.orderDate = orderDate;
    }

    // Getter & Setter 메서드들
    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getOrderStatus() {
        return orderState;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderState = orderStatus;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    // 배송지 관련 getter & setter
    public String getDlvyName() {
        return dlvyName;
    }

    public void setDlvyName(String dlvyName) {
        this.dlvyName = dlvyName;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAddrDetail() {
        return addrDetail;
    }

    public void setAddrDetail(String addrDetail) {
        this.addrDetail = addrDetail;
    }

    public int getPostNo() {
        return postNo;
    }

    public void setPostNo(int postNo) {
        this.postNo = postNo;
    }

    public String getDlvyMemo() {
        return dlvyMemo;
    }

    public void setDlvyMemo(String dlvyMemo) {
        this.dlvyMemo = dlvyMemo;
    }

    // 상품 관련 getter & setter
    public int getItemNo() {
        return itemNo;
    }

    public void setItemNo(int itemNo) {
        this.itemNo = itemNo;
    }

    public int getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(int orderPrice) {
        this.orderPrice = orderPrice;
    }

    public Integer getPointShopGoodsNo() {
        return pointShopGoodsNo;
    }

    public void setPointShopGoodsNo(Integer pointShopGoodsNo) {
        this.pointShopGoodsNo = pointShopGoodsNo;
    }

    public int getDlvyCharge() {
        return dlvyCharge;
    }

    public void setDlvyCharge(int dlvyCharge) {
        this.dlvyCharge = dlvyCharge;
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay;
    }

    public String getPayDetail() {
        return payDetail;
    }

    public void setPayDetail(String payDetail) {
        this.payDetail = payDetail;
    }

    public String getPaymentKey() {
        return paymentKey;
    }

    public void setPaymentKey(String paymentKey) {
        this.paymentKey = paymentKey;
    }

    // 주문 상태 및 기타 관련 getter & setter
    public String getOrderState() {
        return orderState;
    }

    public void setOrderState(String orderState) {
        this.orderState = orderState;
    }

    public String getConfirmDate() {
        return confirmDate;
    }

    public void setConfirmDate(String confirmDate) {
        this.confirmDate = confirmDate;
    }

    public int getReviewExist() {
        return reviewExist;
    }

    public void setReviewExist(int reviewExist) {
        this.reviewExist = reviewExist;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
