package com.minimalFrame.orders.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.minimalFrame.orders.vo.OrdersVO;

// MyBatis 매퍼 인터페이스 선언
@Mapper
public interface OrdersMapper {
    
    // 특정 사용자 ID의 주문 목록 조회
    List<OrdersVO> getOrders(@Param("memberId") String memberId);

    // 주문 추가
    void addOrder(OrdersVO order);

    // 특정 주문 삭제
    void removeOrder(@Param("orderNo") int orderNo);  // orderId -> orderNo로 수정

    // 주문 상태 업데이트
    void updateOrderStatus(@Param("orderNo") int orderNo, @Param("orderStatus") String orderStatus);  // orderId -> orderNo로 수정
}
