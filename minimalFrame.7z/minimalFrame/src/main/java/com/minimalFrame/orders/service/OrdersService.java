package com.minimalFrame.orders.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minimalFrame.orders.mapper.OrdersMapper;
import com.minimalFrame.orders.vo.OrdersVO;

@Service
public class OrdersService {

    @Autowired
    private OrdersMapper ordersMapper;

    // 로그인한 사용자의 주문 목록 조회
    public List<OrdersVO> getOrdersListByMemberId(String memberId) {
        return ordersMapper.getOrders(memberId);  // mapper에서 memberId 기반으로 주문 목록 조회
    }

    // 주문 추가
    public void addOrder(OrdersVO order) {
        ordersMapper.addOrder(order);
    }

    // 특정 주문 삭제
    public void removeOrder(int orderNo) {
        ordersMapper.removeOrder(orderNo);
    }

    // 주문 상태 업데이트
    public void updateOrderStatus(int orderNo, String orderStatus) {
        ordersMapper.updateOrderStatus(orderNo, orderStatus);
    }

	public List<OrdersVO> getOrders(String memberId) {
		// TODO Auto-generated method stub
		return null;
	}
}
