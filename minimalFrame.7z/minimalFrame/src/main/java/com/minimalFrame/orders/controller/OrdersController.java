package com.minimalFrame.orders.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.minimalFrame.orders.service.OrdersService;
import com.minimalFrame.orders.vo.OrdersVO;
import com.minimalFrame.member.vo.MemberVO;

@Controller
@RequestMapping("/orders")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    // 로그인 상태에서 주문 내역 조회
    @GetMapping("/list.do")
    public String getOrdersList(HttpSession session, Model model) {
        // 세션에서 로그인 정보 확인
        String memberId = MemberVO.getMemberId(session); // 세션에서 memberId를 가져옵니다.

        // 로그인 상태 확인
        if (memberId == null) {
            return "redirect:/member/loginForm.do"; // 로그인하지 않은 경우 로그인 페이지로 리디렉션
        }

        // 로그인한 경우 해당 사용자 주문 목록 조회
        List<OrdersVO> ordersList = ordersService.getOrdersListByMemberId(memberId);
        model.addAttribute("ordersList", ordersList);

        return "orders/ordersList"; // 주문 목록 페이지 반환
    }

    // 주문 추가
    @PostMapping("/add")
    public String addOrder(@ModelAttribute OrdersVO order) {
        ordersService.addOrder(order);
        return "redirect:/orders/list.do"; // 주문 추가 후 주문 목록으로 리디렉션
    }

    // 주문 삭제
    @PostMapping("/remove")
    public String removeOrder(@RequestParam("orderNo") int orderNo, @RequestParam("memberId") String memberId) {
        ordersService.removeOrder(orderNo);
        return "redirect:/orders/list.do"; // 주문 삭제 후 주문 목록으로 리디렉션
    }

    // 주문 상태 업데이트
    @PostMapping("/updateStatus")
    public String updateOrderStatus(@RequestParam("orderNo") int orderNo, @RequestParam("orderStatus") String orderStatus) {
        ordersService.updateOrderStatus(orderNo, orderStatus);
        return "redirect:/orders/list.do"; // 주문 상태 업데이트 후 주문 목록으로 리디렉션
    }
}
