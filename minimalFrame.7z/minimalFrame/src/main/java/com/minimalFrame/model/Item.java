package com.minimalFrame.model;

import lombok.Data;

@Data
public class Item {
	private Long itemNo; // 상품 번호
	private String itemName; // 상품명
	private String itemContent; // 상품 설명
	private String itemImage; // 이미지 경로
	private Double Price; // 가격
	private Integer purchase; // 구매 횟수
	private Long category; // 카테고리

	}

