package com.minimalFrame.member.controller;

import java.util.Map;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonParser;
import com.github.scribejava.core.model.OAuth2AccessToken;
import com.google.gson.JsonElement;
import com.minimalFrame.email.service.EmailService;
import com.minimalFrame.member.easyLogin.NaverLoginBO;
import com.minimalFrame.member.service.MemberService;
import com.minimalFrame.member.service.UserMemberService;
import com.minimalFrame.member.vo.MemberVO;

import lombok.Data;
import lombok.extern.log4j.Log4j;

@Controller
@Data
@RequestMapping("/member")
@Log4j
public class MemberController {

	@Autowired
	private MemberService mService;
	
	@Autowired
	private EmailService eService; // EmailService 주입
	
	@Autowired
	private UserMemberService uService;
	
	@Autowired
	private NaverLoginBO naverLoginBO;

    // 회원 가입 폼
    @GetMapping("/signUpForm.do")
    public String signUpForm(@ModelAttribute("vo") MemberVO vo, HttpSession session) {
        // 세션에 저장된 requestEmailAuth가 있다면 폼에 데이터 채우기
        if (session.getAttribute("requestEmailAuth") != null) {
            vo = (MemberVO) session.getAttribute("requestEmailAuth");
        }
        return "member/signUpForm"; // JSP 파일명 (확장자 제외)
    }
    
    // 이메일 인증 요청
    @PostMapping("/requestEmailAuth.do")
    @ResponseBody
    public ResponseEntity<Map<String, String>> requestEmailAuth(
            @RequestParam String email,
            HttpSession session) throws Exception {

        Map<String, String> response = new HashMap<>();

        eService.authCodeSendEmail(email);
        response.put("status", "success");
        response.put("message", "인증 코드가 발송되었습니다.");

        response.put("redirectUrl", "/member/signUpForm.do?&email=" + email);
        return ResponseEntity.ok(response);
    }

    // 인증 코드 확인
    @PostMapping("/checkAuthCode.do")
    @ResponseBody
    public ResponseEntity<Map<String, String>> checkAuthCode(
            @RequestParam String email, 
            @RequestParam String authCode) {
        
        Map<String, String> response = new HashMap<>();
        
        try {
            boolean valid = eService.checkAuthCode(email, authCode);
            if (valid) {
                response.put("status", "success");
                response.put("message", "이메일 인증 성공!");
            } else {
                response.put("status", "error");
                response.put("message", "인증 코드가 일치하지 않습니다.");
            }
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("인증 코드 확인 오류", e);
            response.put("status", "error");
            response.put("message", "서버 오류: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 회원 가입 처리
    @PostMapping("/signUp.do")
    @ResponseBody
    public ResponseEntity<Map<String, String>> signUp(@Valid MemberVO vo, BindingResult result, @RequestParam String authCode, HttpSession session) throws Exception {
        Map<String, String> response = new HashMap<>();

        if (result.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            result.getAllErrors().forEach(error -> sb.append(error.getDefaultMessage()).append("<br>"));
            response.put("status", "error");
            response.put("message", sb.toString());
            return ResponseEntity.badRequest().body(response); // JSON 응답 반환
        }

        // 이메일 인증 확인
        boolean valid = eService.checkAuthCode(vo.getEmail(), authCode);
        if (!valid) {
            response.put("status", "error");
            response.put("resultMessage", "이메일 인증에 실패했습니다.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response); // JSON 응답 반환
        }

        // 회원 가입 및 인증 코드 발송
        mService.signUpAndSendAuthCode(vo);

        response.put("status", "success");
        response.put("message", "회원가입 성공");
        // 회원가입 성공 후 세션 정보 삭제
        session.removeAttribute("requestEmailAuth");
        return ResponseEntity.ok(response); // JSON 응답 반환
    }

	// 아이디, 이메일 중복 체크
    @PostMapping("/checkId.do")
    public ResponseEntity<String> checkId(@RequestParam String memberId) {
    	log.info(memberId);
        boolean exists = mService.checkId(memberId);
        log.info(exists);
        return exists ? ResponseEntity.ok("exists") : ResponseEntity.ok("available");
    }

    @PostMapping("/checkEmail.do")
    public ResponseEntity<String> checkEmail(@RequestParam String email) {
    	log.info(email);
        boolean exists = mService.checkEmail(email);
        log.info(exists);
        return exists ? ResponseEntity.ok("exists") : ResponseEntity.ok("available");
    }
    
	// 아이디, 비밀번호 찾기 폼
	@GetMapping("/findIdAndPw.do")
	public String findIdAndPw() {
	    return "member/findIdAndPw";
	}
	
	// 아이디 찾기 처리
	@PostMapping("/findId.do")
	public String findId(MemberVO vo, RedirectAttributes rttr) {
	    String memberId = mService.findId(vo);
	    
	    if(memberId != null && !memberId.isEmpty()) {
	        rttr.addFlashAttribute("foundId", memberId);
	        rttr.addFlashAttribute("resultMessage", "회원님의 아이디는 " + memberId + "입니다.");
	    } else {
	        rttr.addFlashAttribute("resultMessage", "일치하는 회원 정보가 없습니다.");
	    }
	    
	    return "redirect:/member/findIdAndPw.do";
	}

	// 비밀번호 찾기 처리
	@PostMapping("/findPw.do")
	public String findPw(MemberVO vo, HttpServletRequest request, RedirectAttributes rttr) {
	    // 비밀번호 찾기 - 아이디와 이메일만 확인
	    MemberVO memberInfo = mService.findPw(vo);
	    
	    if(memberInfo != null) {
	        // 비밀번호 재설정 이메일 발송
	        String resetUrl = request.getScheme() + "://" + request.getServerName();
	        if(request.getServerPort() != 80 && request.getServerPort() != 443) {
	            resetUrl += ":" + request.getServerPort();
	        }
	        resetUrl += request.getContextPath();
	        
	        eService.sendPasswordResetEmail(memberInfo.getEmail(), memberInfo.getMemberId(), resetUrl);
	        
	        rttr.addFlashAttribute("emailSent", "true");
	        rttr.addFlashAttribute("email", memberInfo.getEmail());
	        rttr.addFlashAttribute("resultMessage", "입력하신 이메일로 비밀번호 변경 링크를 발송했습니다.");
	    } else {
	        rttr.addFlashAttribute("resultMessage", "등록되지 않은 회원입니다. 다시 확인해주세요.");
	    }
	    
	    rttr.addFlashAttribute("activeTab", "memberPw");
	    return "redirect:/member/findIdAndPw.do";
	}
	
    // 회원가입 성공 페이지
    @GetMapping("/signUpSuccess.do")
    public String signUpSuccess() {
        return "member/signUpSuccess";
    }
    
 // 네이버 로그인 콜백 처리
    @RequestMapping(value = "/naverCallback.do", method = RequestMethod.GET)
    public String naverCallback(@RequestParam String code, @RequestParam String state,
                              HttpSession session, RedirectAttributes rttr) throws IOException, ParseException {
        System.out.println("네이버 콜백 시작");
    	
    	// 네이버 로그인 접근 토큰 획득
        OAuth2AccessToken oauthToken = naverLoginBO.getAccessToken(session, code, state);
        System.out.println("토큰 획득 완료: " + (oauthToken != null));
        
        // 토큰이 없으면 로그인 실패
        if(oauthToken == null) {
            rttr.addFlashAttribute("resultMessage", "네이버 로그인에 실패했습니다.");
            return "redirect:/member/loginForm.do";
        }
        
        // 네이버 API를 통해 사용자 정보 가져오기
        String apiResult = naverLoginBO.getUserProfile(oauthToken);
        JSONObject response = extractUserInfoFromJson(apiResult);
        System.out.println("사용자 정보 획득: " + apiResult);
        
        // 필요한 사용자 정보 추출
        String naverId = (String) response.get("id");
        
        // 네이버 ID로 회원 조회
        MemberVO member = mService.findByNaverId(naverId);
        
        // 회원이 없으면 자동 가입
        if (member == null) {
            member = createNaverMember(response);
            mService.registerNaverMember(member);
            member = mService.findByNaverId(naverId);
        }
        
        // 로그인 처리
        if (member != null) {
            // 계정 상태 확인
            if(!"정상".equals(member.getStatus())) {
                rttr.addFlashAttribute("resultMessage", "로그인에 실패했습니다: " + member.getStatus());
                return "redirect:/member/loginForm.do";
            }
            
            // 세션에 로그인 정보 저장
            session.setAttribute("login", member);
            
            // 회원 등급에 따른 페이지 이동
            if(member.getGradeNo() == 9) {
                return "redirect:/member/admin/list.do";
            } else if(member.getGradeNo() == 1) {
                return "redirect:/member/user/info.do";
            } else {
                return "redirect:/"; 
            }
        } else {
            rttr.addFlashAttribute("resultMessage", "네이버 로그인에 실패했습니다.");
            return "redirect:/member/loginForm.do";
        }
    }

    // JSON에서 사용자 정보 추출
    private JSONObject extractUserInfoFromJson(String apiResult) throws ParseException {
        JSONParser parser = new JSONParser();
        JSONObject jsonObj = (JSONObject) parser.parse(apiResult);
        return (JSONObject) jsonObj.get("response");
    }

    // 네이버 정보로 회원 객체 생성
    private MemberVO createNaverMember(JSONObject response) {
        MemberVO member = new MemberVO();
        
        // 기본값 설정
        String naverId = (String) response.get("id");
        member.setNaverId(naverId);
        member.setEmail(response.containsKey("email") ? (String) response.get("email") : "naver@example.com");
        member.setMemberName(response.containsKey("name") ? (String) response.get("name") : "네이버회원");
        member.setTel(response.containsKey("mobile") ? (String) response.get("mobile") : "010-0000-0000");
        
        // 성별 처리
        String naverGender = response.containsKey("gender") ? (String) response.get("gender") : "M";
        member.setGender("M".equals(naverGender) ? "남자" : "여자");
        
        // 필수 필드 설정
        member.setBirth(new java.util.Date());
        member.setMemberId("naver_" + naverId.substring(0, Math.min(8, naverId.length())));
        member.setMemberPw("naverLogin123!");
        member.setMemberAddress("네이버 회원 기본 주소");
        member.setJoinDate(new java.util.Date());
        member.setGradeNo(1);
        member.setStatus("정상");
        
        return member;
    }
    
    // 로그인폼
	@GetMapping("/loginForm.do")
	public String loginForm(Model model, HttpSession session) {
		String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
		model.addAttribute("naverAuthUrl", naverAuthUrl);
		return "member/loginForm";
	}
    
	// 로그인
	@PostMapping("/login.do")
	public String login(MemberVO vo, HttpSession session, RedirectAttributes rttr) {
	    
	    MemberVO login = mService.login(vo);
	    
	    // login 처리
	    if(login != null) {
	        // 계정 상태 확인 (이미 쿼리에서 확인했지만 더블 체크)
	        if(!"정상".equals(login.getStatus())) {
	            rttr.addFlashAttribute("resultMessage", "로그인에 실패했습니다. 관리자에게 문의 하세요.: " + login.getStatus());
	            return "redirect:/member/loginForm.do";
	        }
	        
	        // 세션에 로그인 정보 저장
	        session.setAttribute("login", login);
	        
	        // 회원 등급에 따른 페이지 이동
	        if(login.getGradeNo() == 9) {
	            return "redirect:/member/admin/list.do";
	        } else if(login.getGradeNo() == 1) {
	            return "redirect:/member/user/info.do";
	        } else {
	            return "redirect:/"; 
	        }
	    } else {
	        rttr.addFlashAttribute("resultMessage", "아이디 또는 비밀번호가 일치하지 않습니다.");
	        return "redirect:/member/loginForm.do";
	    }
	}
		
	// 로그아웃
	@GetMapping("/logout.do")
	public static String logout(HttpSession session) {
		
		// session.invalidate(); - 1. 세션 날리기
		session.removeAttribute("login"); // - 2. 로그인 정보 지우기
		
		return "";
	}    

	
}