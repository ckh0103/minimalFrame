package com.minimalFrame.member.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.minimalFrame.member.service.UserMemberService;
import com.minimalFrame.member.vo.MemberVO;

import lombok.Data;
import lombok.extern.log4j.Log4j;
import oracle.jdbc.proxy.annotation.Post;

@Controller
@Data
@Log4j
@RequestMapping("/member/user")
public class UserMemberController {

	@Autowired
	private UserMemberService service;
	
	@GetMapping("/myPage.do")
	public String myPage(HttpSession session) {
	    String memberId = MemberVO.getMemberId(session);
	    
	    // 로그인 상태 확인
	    if (memberId == null) {
	        // 로그아웃 상태면 로그인 페이지로 리다이렉트
	        return "redirect:/member/loginForm.do";  // 로그인 페이지 경로 확인 필요
	    }
	    
		return "member/user/myPage";
	}
	
	// 내 정보 상세 보기
	@GetMapping("/info.do")
	public String myInfo(
	        @RequestParam(value = "memberNo", required = false, defaultValue = "0") int memberNo,
	        Model model, HttpSession session) {
	    
	    // 세션에서 로그인 정보 확인
	    String memberId = MemberVO.getMemberId(session);
	    
	    // 로그인 상태 확인
	    if (memberId == null) {
	        return "redirect:/member/loginForm.do";
	    }
	    
	    // 로그인 상태면 정보 조회
	    MemberVO vo = new MemberVO();
	    vo.setMemberId(memberId);
	    
	    MemberVO moreInfo = service.myInfo(vo);
	    log.info("조회된 회원 정보: " + moreInfo);
	    
	    // 조회 결과가 없는 경우 처리
	    if (moreInfo == null) {
	        session.invalidate();
	        return "redirect:/member/loginForm.do";
	    }
	    
	    model.addAttribute("vo", moreInfo);
	    return "member/user/info";
	}

	// 내 정보 수정 폼
	@GetMapping("/editForm.do")
	public String userEditForm(
	        @RequestParam(value = "memberNo", required = false, defaultValue = "0") int memberNo,
	        Model model, HttpSession session) {
	    
	    // 세션에서 로그인 정보 확인
	    String memberId = MemberVO.getMemberId(session);
	    
	    // 로그인 상태 확인
	    if (memberId == null) {
	        return "redirect:/member/loginForm.do";
	    }
	    
	    // 로그인 상태면 정보 조회
	    MemberVO vo = new MemberVO();
	    vo.setMemberId(memberId);
	    
	    MemberVO memberInfo = service.myInfo(vo);
	    log.info("수정폼에 표시할 회원 정보: " + memberInfo);
	    
	    // 조회 결과가 없는 경우 처리
	    if (memberInfo == null) {
	        session.invalidate();
	        return "redirect:/member/loginForm.do";
	    }
	    
	    model.addAttribute("vo", memberInfo);
	    return "member/user/editForm";
	}

	// 내 정보 수정 처리
	@PostMapping("/edit.do")
	public String userInfoEdit(
	        @RequestParam(value = "memberNo", required = false, defaultValue = "0") int memberNo,
	        MemberVO vo, RedirectAttributes rttr, HttpSession session) {
	    
	    // 세션에서 로그인 정보 확인
	    String memberId = MemberVO.getMemberId(session);
	    
	    // 로그인 상태 확인
	    if (memberId == null) {
	        return "redirect:/member/loginForm.do";
	    }
	    
	    // 보안: 세션의 ID로 설정하여 다른 회원 정보 변경 방지
	    vo.setMemberId(memberId);
	    
	    log.info("수정 요청 받은 회원 정보: " + vo);
	    
	    int result = service.userInfoEdit(vo);
	    
	    if (result > 0) {
	        rttr.addFlashAttribute("resultMessage", "내 정보가 성공적으로 수정되었습니다.");
	        return "redirect:info.do?memberNo=" + vo.getMemberNo();
	    } else {
	        rttr.addFlashAttribute("resultMessage", "내 정보 수정에 실패했습니다.");
	        return "redirect:editForm.do?memberNo=" + vo.getMemberNo();
	    }
	}
	
	// 비밀번호 변경 폼
	@GetMapping("/editPasswordForm.do")
	public String editPasswordForm(
	        @RequestParam(value = "memberId", required = false) String paramId,
	        Model model, HttpSession session) {
	    
	    String memberId = null;
	    MemberVO memberInfo = null;
	    
	    // 1. URL 파라미터 id가 있는 경우 (비밀번호 찾기를 통한 접근)
	    if (paramId != null) {
	        memberId = paramId;
	        
	        // 회원 ID로 정보 조회
	        MemberVO vo = new MemberVO();
	        vo.setMemberId(memberId);
	        memberInfo = service.myInfo(vo);
	        
	        if (memberInfo != null) {
	            model.addAttribute("memberVO", memberInfo);
	            model.addAttribute("fromEmail", true); // 비밀번호 찾기에서 접근했음을 표시
	            return "member/user/editPasswordForm";
	        } else {
	            // 유효하지 않은 ID인 경우
	            return "redirect:/member/loginForm.do";
	        }
	    }
	    
	    // 2. URL 파라미터가 없는 경우 (일반 로그인 사용자)
	    memberId = MemberVO.getMemberId(session);
	    
	    if (memberId == null) {
	        return "redirect:/member/loginForm.do";
	    }
	    
	    // 로그인한 사용자 정보 조회
	    MemberVO vo = new MemberVO();
	    vo.setMemberId(memberId);
	    memberInfo = service.myInfo(vo);
	    
	    if (memberInfo == null) {
	        session.invalidate();
	        return "redirect:/member/loginForm.do";
	    }
	    
	    // 모델에 추가
	    model.addAttribute("memberVO", memberInfo);
	    
	    return "member/user/editPasswordForm";
	}

	@PostMapping("/editPassword.do")
	public String editPassword(
	        @RequestParam(value = "fromEmail", required = false) String fromEmail,
	        MemberVO vo, RedirectAttributes rttr, HttpSession session) {
	    
	    // 비밀번호 찾기에서 온 요청인지 확인
	    boolean isFromEmail = "true".equals(fromEmail);
	    
	    if (!isFromEmail) {
	        // 일반 로그인 사용자 - 세션 체크
	        String memberId = MemberVO.getMemberId(session);
	        
	        if (memberId == null) {
	            return "redirect:/member/loginForm.do";
	        }
	        
	        // 회원 정보 조회
	        MemberVO infoVO = new MemberVO();
	        infoVO.setMemberId(memberId);
	        MemberVO memberInfo = service.myInfo(infoVO);
	        
	        if (memberInfo == null) {
	            rttr.addFlashAttribute("resultMessage", "회원 정보를 찾을 수 없습니다.");
	            return "redirect:/member/loginForm.do";
	        }
	        
	        // VO에 필요한 정보 설정
	        vo.setMemberNo(memberInfo.getMemberNo());
	        vo.setMemberId(memberId);
	    } else {
	        // 비밀번호 찾기에서 온 요청 - DB에서 회원 정보 재확인
	        MemberVO infoVO = new MemberVO();
	        infoVO.setMemberId(vo.getMemberId());
	        MemberVO memberInfo = service.myInfo(infoVO);
	        
	        if (memberInfo == null) {
	            rttr.addFlashAttribute("resultMessage", "회원 정보를 찾을 수 없습니다.");
	            return "redirect:/member/loginForm.do";
	        }
	        
	        // VO에 필요한 정보 설정
	        vo.setMemberNo(memberInfo.getMemberNo());
	    }
	    
	    System.out.println("수정 요청 받은 비밀 번호: " + vo.getMemberPw() + ", 회원번호: " + vo.getMemberNo());
	    
	    // 비밀번호 변경 처리
	    int result = service.editPassword(vo);
	    
	    if (result > 0) {
	        rttr.addFlashAttribute("resultMessage", "비밀번호가 성공적으로 변경되었습니다. 다시 로그인해주세요.");
	        
	        // 로그인 상태였다면 로그아웃 처리
	        if (!isFromEmail && session.getAttribute("login") != null) {
	            MemberController.logout(session);
	        }
	        
	        return "redirect:/member/loginForm.do";
	        
	    } else {
	        rttr.addFlashAttribute("resultMessage", "비밀번호 변경에 실패했습니다.");
	        
	        if (isFromEmail) {
	            // 파라미터 이름 id로 통일
	            return "redirect:/member/user/editPasswordForm.do?memberId=" + vo.getMemberId();
	        } else {
	            return "redirect:/member/user/editPasswordForm.do";
	        }
	    }
}
	
	@PostMapping("/checkPassword.do")
	@ResponseBody
	public String checkPassword(
			@RequestParam("memberPw") String inputPw, HttpSession session) {
	    System.out.println("비밀번호 확인 요청: inputPassword 길이=" + inputPw.length());
	    
	    // 세션에서 로그인한 사용자 ID 가져오기
	    
	    String memberId = MemberVO.getMemberId(session);
	    
	    if (memberId == null) {
	        return "login_required";
	    }
	    
	    System.out.println("로그인 ID: " + memberId);
	    
	    // DB에서 해당 ID의 비밀번호 조회
	    String dbPassword = service.getPasswordById(memberId);
	    
	    System.out.println("DB 비밀번호 조회: " + (dbPassword != null ? "성공" : "실패"));
	    
	    // 비밀번호 일치 여부 확인
	    if (dbPassword != null && dbPassword.equals(inputPw)) {
	        System.out.println("비밀번호 일치");
	        return "success";
	    } else {
	        System.out.println("비밀번호 불일치");
	        return "fail";
	    }
	}
	
	// 회원 삭제 처리
	@PostMapping("/delete.do")
	public String userInfoDelete(String memberId, MemberVO vo, RedirectAttributes rttr, HttpSession session) {
		
		vo.setMemberId(memberId);
		
		int result = service.userInfoDelete(vo);
		
		if (result > 0) {  // 0보다 클 때가 성공
		    rttr.addFlashAttribute("resultMessage", "정상적으로 탈퇴가 진행되었습니다.");
		    MemberController.logout(session);
		    return "redirect:/member/loginForm.do";
		} else {
		    rttr.addFlashAttribute("resultMessage", "회원 정보를 삭제하지 못했습니다.");
		    return "redirect:info.do?memberNo=" + vo.getMemberNo();
		}
	}
}
