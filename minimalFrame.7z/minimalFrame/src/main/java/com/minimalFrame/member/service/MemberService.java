package com.minimalFrame.member.service;

import java.util.HashMap;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.minimalFrame.email.service.EmailService;
import com.minimalFrame.member.vo.MemberVO;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class MemberService {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
    @Autowired
    private EmailService emailService;

    @Transactional
    public int signUpAndSendAuthCode(MemberVO vo) {
        // 1. 회원 가입
        int signUpResult = signUp(vo);
        if (signUpResult <= 0) {
            throw new RuntimeException("회원 가입 실패"); // 롤백을 위해 예외 발생
        }

        // 2. 인증 코드 발송
        try {
            emailService.authCodeSendEmail(vo.getEmail());
        } catch (Exception e) {
            throw new RuntimeException("인증 코드 발송 실패", e); // 롤백을 위해 예외 발생
        }

        return signUpResult; // 성공 시 1 반환
    }
    
    // 회원 가입
    public int signUp(MemberVO vo) {
        try {
        	 return sqlSession.insert("memberMapper.signUp", vo); // Mapper ID를 정확히 지정
        } catch (Exception e) {
            log.error("회원 가입 실패: " + e.getMessage());
            log.info(vo);
            return 0; // 실패 시 0 반환
        }
    }
	
// 아이디 중복 체크
	public boolean checkId(String memberId) {
		int count = sqlSession.selectOne("memberMapper.cheakId", memberId);
		return count > 0;  // count가 1 이상이면 아이디가 이미 존재
	    }
		
    // 이메일 중복 체크
    public boolean checkEmail(String email) {
    	log.info(email);
    	int count = sqlSession.selectOne("memberMapper.cheakEmail", email);
        return count > 0;  // count가 1 이상이면 이메일이 이미 존재
    }
    
    // 로그인
    public MemberVO login(MemberVO vo) {
        MemberVO result = sqlSession.selectOne("memberMapper.login", vo);
        return result;
    }
    
 // 네이버 ID로 회원 조회
    public MemberVO findByNaverId(String naverId) {
        MemberVO result = sqlSession.selectOne("memberMapper.findByNaverId", naverId);
        return result;
    }

    // 네이버 회원 등록
    public void registerNaverMember(MemberVO member) {
        sqlSession.insert("memberMapper.insertNaverMember", member);
    }
	
    // 인증 코드 저장
    public void insertAuthCode(String email, String authCode) {
        Map<String, Object> map = new HashMap<>();
        map.put("email", email);
        map.put("authCode", authCode);
        sqlSession.insert("memberMapper.insertAuthCode", map);
    }

    // 인증 코드 조회
    public String getAuthCode(String email) {
        return sqlSession.selectOne("memberMapper.getAuthCode", email);
    }
    
    // 아이디 찾기
    public String findId(MemberVO vo) {
        System.out.println("아이디 찾기 요청: " + vo);
        return sqlSession.selectOne("memberMapper.findId", vo);
    }
    
    // 비밀번호 찾기
    public MemberVO findPw(MemberVO vo) {
        return sqlSession.selectOne("memberMapper.findPw", vo);
    }
}
    