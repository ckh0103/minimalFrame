package com.minimalFrame.member.service;


import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minimalFrame.member.vo.MemberVO;

import lombok.extern.log4j.Log4j;

@Service
public class UserMemberService {

	@Autowired
	private SqlSessionTemplate sqlSession;

	// 내 정보 조회
	public MemberVO myInfo(MemberVO vo) {
	    return sqlSession.selectOne("userMemberMapper.info", vo);
	}

	// 내 정보 수정
	public int userInfoEdit(MemberVO vo) {
	    return sqlSession.update("userMemberMapper.edit", vo);
	}
	
	
	public int userInfoDelete(MemberVO vo) {
		return sqlSession.delete("userMemberMapper.delete", vo);
	}
	
	// 비밀번호수정
	public int editPassword(MemberVO vo) {
		return sqlSession.update("userMemberMapper.editPassword", vo);
	}
	
	// 비밀번호 확인
	public String getPasswordById(String memberId) {
	    return sqlSession.selectOne("userMemberMapper.checkPassword", memberId);
	}
	
}
	

