package com.minimalFrame.member.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.minimalFrame.member.service.AdminMemberService;
import com.minimalFrame.member.vo.MemberVO;
import com.minimalFrame.util.page.PageObject;

import lombok.Data;
import lombok.extern.log4j.Log4j;

@Controller
@Data
@Log4j
@RequestMapping("/member/admin")
public class AdminMemberController {

	@Autowired
	private AdminMemberService service;
	
	// 회원 정보 리스트
	@GetMapping("/list.do")
	public String memberList(HttpServletRequest request, Model model) throws Exception {
		
		PageObject pageObject = PageObject.getInstance(request);
		
	    model.addAttribute("memberList", service.memberList(pageObject));
		System.out.println(pageObject);
		
		model.addAttribute("pageObject", pageObject);

		log.info(model);
		return "member/admin/list";
	}
	
	// 회원 정보 상세 보기
	@GetMapping("/info.do")
	public String memberInfo(MemberVO vo, Model model) {
	    log.info("info.do로 전달된 memberNo: " + vo.getMemberNo());
	    MemberVO moreInfo = service.memberInfo(vo);
	    log.info("조회된 회원 정보: " + moreInfo);

	    model.addAttribute("vo", moreInfo);
	    
	    log.info(model);
	    return "member/admin/info";
	}
	
	// 회원 등록 폼
	@GetMapping("/addForm.do")
	public String memberAddForm() {
		return "member/admin/addForm";
	}
	
	// 회원 등록 처리
	@PostMapping("/add.do")
	public String memberAdd(MemberVO vo, RedirectAttributes rttr) {
	    log.info(vo);
	    
	    int result = service.memberAdd(vo);
	    
	    if(result == 0) {
	        // 추가 실패 시 메시지 처리
	        rttr.addFlashAttribute("resultMessage", "회원 추가에 실패했습니다.");
	        return "redirect:addForm.do";
	    }
	    
	    // 성공 시 메시지
	    rttr.addFlashAttribute("resultMessage", "회원이 성공적으로 등록되었습니다.");
	    return "redirect:list.do";
	}
	

	@GetMapping("/editForm.do")
	public String memberEditForm(@RequestParam(value = "memberNo", required = false, defaultValue = "0")
								int memberNo, MemberVO vo, Model model) {
	    
	    // vo에 memberNo가 제대로 바인딩되지 않은 경우 직접 설정
	    if (vo.getMemberNo() == 0 && memberNo > 0) {
	        vo.setMemberNo(memberNo);
	    }

	    model.addAttribute("memberVO", vo);

    return "member/admin/editForm";
	
}
	// 정보 수정 처리
	@PostMapping("/edit.do")
	public String memberEdit(MemberVO vo, RedirectAttributes rttr) {
	    System.out.println("수정 요청 받은 회원 정보: " + vo);
	    
	    int result = service.memberEdit(vo);
	    
	    if (result > 0) {
	        rttr.addFlashAttribute("resultMessage", "회원 정보가 성공적으로 수정되었습니다.");
	        return "redirect:info.do?memberNo=" + vo.getMemberNo();
	    } else {
	        rttr.addFlashAttribute("resultMessage", "회원 정보 수정에 실패했습니다.");
	        return "redirect:editForm.do?memberNo=" + vo.getMemberNo();
	    }
	}
	
	// 회원 삭제 처리
	@PostMapping("/delete.do")
	public String memberDelete(MemberVO vo, RedirectAttributes rttr) {
		
		int result = service.memberDelete(vo);
		
		if (result > 0) {  // 0보다 클 때가 성공
		    rttr.addFlashAttribute("resultMessage", "회원 정보가 성공적으로 삭제되었습니다.");
		    return "redirect:list.do";
		} else {
		    rttr.addFlashAttribute("resultMessage", "회원 정보를 삭제하지 못했습니다.");
		    return "redirect:info.do?memberNo=" + vo.getMemberNo();
		}
	}
}
