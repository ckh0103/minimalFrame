package com.minimalFrame.member.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minimalFrame.member.vo.MemberVO;
import com.minimalFrame.util.page.PageObject;

@Service
public class AdminMemberService {

	@Autowired
	private SqlSessionTemplate sqlSession;

	// 회원 리스트
	public List<MemberVO> memberList(PageObject pageObject) {
		
	    long totalRow = sqlSession.selectOne("adminMemberMapper.getTotalRow", pageObject);

	    pageObject.setTotalRow(totalRow);

	    return sqlSession.selectList("adminMemberMapper.list", pageObject);
	}

	// 회원 정보 상세 보기
	public MemberVO memberInfo(MemberVO vo) {
	    return sqlSession.selectOne("adminMemberMapper.info", vo);
	}

	public int memberAdd(MemberVO vo) {
		return sqlSession.insert("adminMemberMapper.add", vo);
	}

	public int memberEdit(MemberVO vo) {
		return sqlSession.update("adminMemberMapper.edit", vo);
	}
	
	public int memberDelete(MemberVO vo) {
		return sqlSession.delete("adminMemberMapper.delete", vo);
	}
	
}
	

