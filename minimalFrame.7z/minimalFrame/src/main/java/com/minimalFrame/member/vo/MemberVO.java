package com.minimalFrame.member.vo;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class MemberVO {
	
    private int memberNo;

    @NotBlank(message = "아이디를 입력해주세요.")
    @Size(min = 4, max = 8, message = "아이디는 4자 이상 8자 이하로 입력해야 합니다.")
    @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9]*$", message = "아이디는 영문자 또는 영문자+숫자만 가능합니다.")
    private String memberId;

    @NotBlank(message = "이메일을 입력해주세요.")
    @Email(message = "유효한 이메일 주소를 입력해주세요.")
    private String email;

    @NotBlank(message = "비밀번호를 입력해주세요.")
    @Size(min = 6, max = 20, message = "비밀번호는 6자 이상 20자 이하로 입력해야 합니다.")
    @Pattern(regexp = "^(?=.*[a-zA-Z])(?=.*[0-9]).*$", message = "비밀번호는 영문자와 숫자의 혼용만 가능합니다.")
    private String memberPw;

    @NotBlank(message = "이름을 입력해주세요.")
    @Size(min = 2, max = 10, message = "이름은 2자 이상 10자 이하로 입력해야 합니다.")
    @Pattern(regexp = "^[가-힣]*$", message = "이름은 한글만 입력 가능합니다.")
    private String memberName;

    @NotBlank(message = "성별을 선택해주세요.")
    private String gender;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birth;

    @NotBlank(message = "전화번호를 입력해주세요.")
    @Pattern(regexp = "^\\d{2,3}-\\d{3,4}-\\d{4}$", message = "유효한 전화번호 형식이 아닙니다.")
    private String tel;

    @NotBlank(message = "주소를 입력해주세요.")
    private String memberAddress;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date joinDate;
    
    private int gradeNo;
    private String gradeName;
    private String status;
    
    private String naverId; // 네이버 ID
    private String mobile; // 휴대폰 번호
	
    // session에서 email 가져오기 - overload
    // 사용법 - MemberVO.getEmail(session OR request)
    public static String getEmail(HttpSession session) {
    	MemberVO vo = (MemberVO) session.getAttribute("requestEmailAuth");
    	if(vo == null) return null;
    	return vo.getEmail();
    }
    
    // request에서 session을 호출해서 email 가져오기 - overload
    public static String getEmail(HttpServletRequest request) {
    	HttpSession session = request.getSession();
    	return getEmail(session);
    	
    }
	
	// session에서 id 가져오기 - overload
	// 사용법 - MemberVO.getMemberId(session OR request)
	public static String getMemberId(HttpSession session) {
		MemberVO vo = (MemberVO) session.getAttribute("login");
		if(vo == null) return null;
		return vo.getMemberId();
	}
	
	// request에서 session을 호출해서 id 가져오기 - overload
	public static String getMemberId(HttpServletRequest request) {
		HttpSession session = request.getSession();
		return getMemberId(session);
	}

	
	// session에서 gradeNo 가져오기 - overload
	// 사용법 - MemberVO.getGradeNo(session)
	public static Integer getGradeNo(HttpSession session) {
		MemberVO vo = (MemberVO) session.getAttribute("login");
		if(vo == null) return null;
		return vo.getGradeNo();
	}
	
	// request에서 session을 호출해서 id 가져오기 - overload
	public static Integer getGradeNo(HttpServletRequest request) {
		HttpSession session = request.getSession();
		return getGradeNo(session);
	}
	
}