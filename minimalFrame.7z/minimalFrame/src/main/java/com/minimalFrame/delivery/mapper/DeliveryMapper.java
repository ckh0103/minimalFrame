package com.minimalFrame.delivery.mapper;

import com.minimalFrame.delivery.vo.DeliveryAddressVO;
import com.minimalFrame.delivery.vo.DeliveryVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeliveryMapper {

    // 로그인한 사용자에 대한 배송 정보 조회
    List<DeliveryVO> getDeliveryListByMemberId(@Param("memberId") String memberId);

    // 비회원 배송 정보 조회
    List<DeliveryAddressVO> getGuestDeliveryList();
}