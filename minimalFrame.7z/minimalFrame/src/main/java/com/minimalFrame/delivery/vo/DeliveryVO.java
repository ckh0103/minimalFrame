package com.minimalFrame.delivery.vo;

// 필요한 라이브러리 임포트
public class DeliveryVO {
    // 배송 주소 ID (PK)
    private int deliveryId;

    // 사용자 ID (FK)
    private String memberId;

    // 수령인 이름
    private String recipientName;

    // 전화번호
    private String phoneNumber;

    // 주소
    private String address;

    // 상세 주소
    private String detailAddress;

    // 기본 생성자
    public DeliveryVO() {}

    // 모든 필드를 포함하는 생성자
    public DeliveryVO(int deliveryId, String memberId, String recipientName, String phoneNumber, String address, String detailAddress) {
        this.deliveryId = deliveryId;
        this.memberId = memberId;
        this.recipientName = recipientName;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.detailAddress = detailAddress;
    }

    // Getter & Setter 메서드들
    public int getDeliveryId() {
        return deliveryId;
    }

    public void setDeliveryId(int deliveryId) {
        this.deliveryId = deliveryId;
    }

    public String getmemberId() {
        return memberId;
    }

    public void setmemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDetailAddress() {
        return detailAddress;
    }

    public void setDetailAddress(String detailAddress) {
        this.detailAddress = detailAddress;
    }

	public Object getMemberNo() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setMemberNo(Integer memberNo) {
		// TODO Auto-generated method stub
		
	}




	}
