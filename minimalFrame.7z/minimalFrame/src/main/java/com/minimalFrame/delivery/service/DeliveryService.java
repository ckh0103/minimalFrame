package com.minimalFrame.delivery.service;

import com.minimalFrame.delivery.vo.DeliveryAddressVO;
import com.minimalFrame.delivery.vo.DeliveryVO;
import com.minimalFrame.delivery.mapper.DeliveryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeliveryService {

    @Autowired
    private DeliveryMapper deliveryMapper;

    // 로그인한 사용자의 배송 정보 조회
    public List<DeliveryVO> getMemberDeliveryList(String memberId) {
        return deliveryMapper.getDeliveryListByMemberId(memberId);
    }

    // 비회원의 배송 정보 조회 (예시로 비회원 배송 정보를 가져오는 메서드 추가)
    public List<DeliveryAddressVO> getGuestDeliveryList() {
        return deliveryMapper.getGuestDeliveryList();
    }
}
