package com.minimalFrame.delivery.controller;

import com.minimalFrame.delivery.service.DeliveryService;
import com.minimalFrame.delivery.vo.DeliveryVO;
import com.minimalFrame.member.vo.MemberVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class DeliveryController {

    @Autowired
    private DeliveryService deliveryService;

    // 로그인한 사용자 배송 정보 조회
    @GetMapping("/delivery/list")
    public String deliveryList(HttpSession session, Model model) {
        // 세션에서 로그인된 사용자 정보 가져오기
        // 세션에서 로그인 정보 확인
        String memberId = MemberVO.getMemberId(session);
        


        // 로그인 상태 확인 (memberId가 없거나 공백이면 비회원 조회 페이지로 이동)
        if (memberId == null || memberId.trim().isEmpty()) {
            model.addAttribute("isGuest", true);
            return "delivery/nonMemberDeliveryForm"; // 비회원 배송 조회 JSP로 이동
        }

        // 로그인된 사용자라면 회원 배송 조회
        model.addAttribute("isGuest", false);
        model.addAttribute("memberId", memberId);
        return "delivery/deliveryList"; // delivery/deliveryList.jsp로 이동
    }

    // 비회원 배송 조회 처리 (비회원 배송 조회 폼을 반환)
    @GetMapping("/delivery/nonMember")
    public String nonMemberDeliveryForm() {
        return "delivery/nonMemberDeliveryForm"; // 비회원 배송 조회 JSP로 이동
    }
}
